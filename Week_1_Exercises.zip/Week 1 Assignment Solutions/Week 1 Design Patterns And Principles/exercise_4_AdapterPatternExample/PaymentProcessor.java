package exercise_4_AdapterPatternExample;

public interface PaymentProcessor {
    void processPayment(double amount);
}