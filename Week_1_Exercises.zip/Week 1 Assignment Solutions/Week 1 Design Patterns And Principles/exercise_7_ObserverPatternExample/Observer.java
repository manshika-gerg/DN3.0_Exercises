package exercise_7_ObserverPatternExample;

public interface Observer {
    void update(String stockName, double stockPrice);
}