package exercise_2_FactoryDesignPatternExample;

public abstract class DocumentFactory {
    public abstract Document createDocument();
}
